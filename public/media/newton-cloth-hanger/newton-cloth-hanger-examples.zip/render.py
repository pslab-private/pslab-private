"""Render measured MJWarp joint poses, free cloth vertices and grasp markers."""
import subprocess
import numpy as np
import mujoco as mj
import os
import shutil
from setup_scene import OUT, ASSETS, LIFT, DEPTH

def ffmpeg():
    binary = os.environ.get("FFMPEG_EXE") or shutil.which("ffmpeg")
    if binary:
        return binary
    from imageio_ffmpeg import get_ffmpeg_exe
    return get_ffmpeg_exe()

def values(a): return ' '.join(map(str,np.asarray(a).flatten()))
def render(cutaway=False):
 d=np.load(OUT/'trajectory.npz')
 p,poses,f=d['pos'],d['pose'],d['faces']
 first=d['grip_ids_0']
 ids=[first[p[0,first,0]>=.104],d['grip_ids_1']]
 eye=np.array([.33,1.85,1.41]); view=np.array([-.045,-.01,.96])-eye
 right=np.cross(view,[0,0,1]);up=np.cross(right,view)
 grips=''.join(f'<body name="grip{g}" mocap="true"><geom type="sphere" size=".014" rgba="{rgb} 1"/></body>' for g,rgb in enumerate(['.96 .30 .18','.18 .83 .60']))
 xml=f"""<mujoco><visual><global offwidth="768" offheight="576"/></visual>
 <asset><material name="matte" rgba=".17 .48 .77 {0.27 if cutaway else 1.0}" specular="0" shininess="0"/><mesh name="hanger" file="{(ASSETS/'hanger.obj').as_posix()}"/></asset>
 <worldbody><body name="rack" mocap="true"><geom type="mesh" mesh="hanger" pos="0 {-DEPTH} {-LIFT-.275}" rgba=".88 .58 .22 1"/></body>{grips}
 <geom type="box" pos="0 .16 .38" size=".70 .63 .04" rgba=".23 .26 .29 1"/><light pos="1 2 3" dir="-.3 -.6 -1"/><camera name="front" pos="{values(eye)}" xyaxes="{values(right)} {values(up)}" fovy="39"/></worldbody>
 <deformable><flex name="shirt" body="world" dim="2" vertex="{values(p[0])}" element="{values(f)}" material="matte" radius=".001"/></deformable></mujoco>"""
 model=mj.MjModel.from_xml_string(xml);data=mj.MjData(model)
 ff=ffmpeg()
 command=[str(ff),'-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','768x576','-r','30','-i','-','-c:v','libx264','-pix_fmt','yuv420p',str(OUT/('cutaway.mp4' if cutaway else 'simulation.mp4'))]
 with mj.Renderer(model,height=576,width=768) as renderer,subprocess.Popen(command,stdin=subprocess.PIPE) as enc:
  for v,q,on in zip(p,poses,d['active']):
   data.mocap_pos[0]=q[:3]
   yaw,pitch=q[3:]/2
   data.mocap_quat[0]=[np.cos(yaw)*np.cos(pitch),-np.sin(yaw)*np.sin(pitch),np.cos(yaw)*np.sin(pitch),np.sin(yaw)*np.cos(pitch)]
   for i,g in enumerate(ids):
    data.mocap_pos[i+1]=v[g].mean(0)+[0,.009,0] if on[i] else [0,0,-10]
   mj.mj_forward(model,data);data.flexvert_xpos[:]=v;renderer.update_scene(data,camera='front');enc.stdin.write(renderer.render().tobytes())
  enc.stdin.close();assert enc.wait()==0
def combine():
    vf="[0:v][1:v]hstack,scale=1280:480"
    ff=ffmpeg()
    subprocess.run([str(ff),'-y','-loglevel','error','-i',str(OUT/'simulation.mp4'),'-i',str(OUT/'cutaway.mp4'),
                    '-filter_complex',vf,'-c:v','libx264','-pix_fmt','yuv420p',str(OUT/'dressing.mp4')],check=True)

if __name__=='__main__':
    render()
    render(cutaway=True)
    combine()
