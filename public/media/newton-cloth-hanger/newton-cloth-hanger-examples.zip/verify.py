import numpy as np


from setup_scene import OUT
def caps(f):
    edges=f[:,[[0,1],[1,2],[2,0]]].reshape(-1,2)
    _,inv,cnt=np.unique(np.sort(edges,1),axis=0,return_inverse=True,return_counts=True)
    rev={j:i for i,j in edges[cnt[inv]==1]}
    loops=[]
    while rev:
        v=next(iter(rev));l=[]
        while v in rev: l.append(v);v=rev.pop(v)
        loops.append(np.array(l))
    return loops
def rot(q):
    cy,sy=np.cos(q[3]),np.sin(q[3]);c,s=np.cos(q[4]),np.sin(q[4])
    return np.array([[cy*c,-sy,cy*s],[sy*c,cy,sy*s],[-s,0,c]])
def winding(v,f,loops,g):
    tri=v[f]
    for l in loops:
        tri=np.concatenate([tri,np.stack([v[l],v[np.roll(l,-1)],np.tile(v[l].mean(0),(len(l),1))],axis=1)])
    a,b,c=(tri-g).transpose(1,0,2);al,bl,cl=[np.linalg.norm(x,axis=1) for x in (a,b,c)]
    dot=lambda a,b:np.sum(a*b,axis=1)
    return abs(np.arctan2(dot(a,np.cross(b,c)),al*bl*cl+dot(a,b)*cl+dot(b,c)*al+dot(c,a)*bl).sum()/(2*np.pi))
if __name__=='__main__':
    from setup_scene import shoulder_pads
    d=np.load(OUT/'trajectory.npz')
    p,f=d['pos'],d['faces']
    loops=caps(f)
    ids=np.flatnonzero(~d['active'].any(1))
    assert np.isfinite(p).all() and np.all(np.diff(ids)==1)
    pads=np.array([[x,0,.003-.38*abs(x)] for x,z,r in shoulder_pads()])
    endpads=pads[[0,8,9,17]]
    inside=[]
    for frame in ids:
        q=d['pose'][frame]
        inside.append([winding(p[frame],f,loops,point)>.5 for point in endpads@rot(q).T+q[:3]])
    first_pull=np.flatnonzero(d['active'][:,1])[0]
    for frame in (0,first_pull-1):
        q=d["pose"][frame]
        tips=pads[[17,8]]@rot(q).T+q[:3]
        membership=[winding(p[frame],f,loops,x)>.5 for x in tips]
        print("right/left tips inside",frame/30,membership)
        assert membership==([False,False] if frame==0 else [True,False])
    gap=d['pad_gap'];cross=d['wire_hits']; events=np.where(cross>0)[0]
    print("released at",ids[0]/30,"seconds; checked",len(ids),"released frames; all four pad centers inside",np.all(inside))
    print("substeps",len(gap),"min pad clearance mm",1000*gap.min(),"wire intersection steps",len(events))
    if len(events):
        print("intersection intervals (s)",[(seg[0]/600,seg[-1]/600) for seg in np.split(events,np.flatnonzero(np.diff(events)>1)+1)])
    print("lift cm",100*(p[30,d['grip_ids_0'],2]-p[0,d['grip_ids_0'],2]).mean(),
          "final tabletop clearance cm",100*(p[-1,:,2].min()-.42))
    hook_caps=d["hook_cap_hits"]
    winding_max=np.max(np.abs(d["hook_winding"]))
    print("curved hook/opening crossing steps",np.count_nonzero(hook_caps),"max outside winding error",winding_max)
    assert len(gap)==20*(len(p)-1) and np.all(gap<1.)
    assert np.all(inside) and gap.min()>0 and p[-1,:,2].min()>.42
    assert not np.any(cross) and not np.any(hook_caps) and winding_max<.01
