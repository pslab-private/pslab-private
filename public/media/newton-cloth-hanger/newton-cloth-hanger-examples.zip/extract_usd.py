"""Extract the authored panel corners and place the Newton example shirt on our hanger."""
import numpy as np
from pxr import Usd, UsdGeom
from setup_scene import ASSETS, DEPTH, shoulder_pads

stage = Usd.Stage.Open(str(ASSETS/"Female_T_Shirt.usd"))
mesh = UsdGeom.Mesh(stage.GetPrimAtPath("/Root/Female_T_Shirt/Root_Garment"))
assert UsdGeom.GetStageMetersPerUnit(stage)==1 and set(mesh.GetFaceVertexCountsAttr().Get())=={3}
points = np.array(mesh.GetPointsAttr().Get())
faces = np.array(mesh.GetFaceVertexIndicesAttr().Get()).reshape(-1,3)
st = UsdGeom.PrimvarsAPI(mesh).GetPrimvar("st")
assert st.IsIndexed() and st.GetInterpolation()=="faceVarying"
uv = np.array(st.Get())*.001  # Same millimetre-to-metre conversion as Newton's garment example.
corners = np.array(st.GetIndices()).reshape(-1,3)
assert corners.shape==faces.shape
signed_area = np.linalg.det(uv[corners][:,1:]-uv[corners][:,:1])/2
print(len(points),len(faces),len(uv),signed_area.min(),signed_area.sum(),(signed_area<=0).sum())
assert np.all(signed_area>0)
vertices = points[:,[0,2,1]].copy()
vertices[:,0] *= -1
vertices += [0.,.08,-.365]
centers=np.array([(x,DEPTH,z) for x,z,_ in shoulder_pads()])
assert np.linalg.norm(vertices[:,None]-centers,axis=2).min() > .024+.008
np.savez_compressed(ASSETS/"Female_T_Shirt_panels.npz",vertices=vertices,faces=faces,uv=uv,corners=corners)
