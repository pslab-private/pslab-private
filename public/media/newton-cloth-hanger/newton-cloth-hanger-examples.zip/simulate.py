"""Single-shoulder lift and neck-first hanger insertion. Distances are in metres."""
from pathlib import Path
import numpy as np
import mujoco
import mujoco_warp as mjw
import newton
import warp as wp
from newton.solvers import style3d
from setup_scene import ASSETS, OUT, DEPTH, LIFT, shoulder_pads, read_mesh, local_panels

PIV=np.array([0.,DEPTH,LIFT+.275])
FPS=30
DT=1/600
@wp.kernel
def control(command:wp.array[float],ctrl:wp.array2d[float]):
    i=wp.tid()
    ctrl[0,i]=command[i]

@wp.kernel
def transfer(q:wp.array2d[float],out:wp.array[wp.transform]):
    yaw=wp.quat_from_axis_angle(wp.vec3(0.,0.,1.),q[0,3])
    pitch=wp.quat_from_axis_angle(wp.vec3(0.,1.,0.),q[0,4])
    out[0]=wp.transform(wp.vec3(q[0,0],q[0,1],q[0,2]),yaw*pitch)

@wp.kernel
def grip(group:wp.array[int],active:wp.array[int],delta:wp.array[wp.vec3],saved:wp.array[wp.vec3],
         flags:wp.array[int],q:wp.array[wp.vec3],v:wp.array[wp.vec3]):
    i=wp.tid()
    g=group[i]
    flags[i]=1
    if g>=0 and active[g]!=0:
        flags[i]=0
        q[i]=saved[i]+delta[g]
        v[i]=wp.vec3(0.)

from newton._src.geometry.kernels import triangle_closest_point

@wp.kernel
def clearance(q:wp.array[wp.vec3],faces:wp.array2d[int],pads:wp.array[wp.vec3],
              pose:wp.array[wp.transform],step:wp.array[int],gap:wp.array[float]):
    i,j=wp.tid()
    center=wp.transform_point(pose[0],pads[j])
    a=q[faces[i,0]];b=q[faces[i,1]];c=q[faces[i,2]]
    lower=wp.min(a,wp.min(b,c));upper=wp.max(a,wp.max(b,c))
    separation=wp.max(lower-center,center-upper)
    if wp.max(separation)>.05:
        return
    near,weights,kind=triangle_closest_point(a,b,c,center)
    wp.atomic_min(gap,step[0],wp.length(near-center)-.024)

@wp.func
def intersects(a:wp.vec3,b:wp.vec3,c:wp.vec3,u:wp.vec3,v:wp.vec3,w:wp.vec3):
    # Warp's Moller test uses a fixed epsilon on unnormalized plane equations.
    # Use centimetres and doubles so millimetre wire facets are not classified as coplanar.
    scale=wp.float64(100.)
    return wp.intersect_tri_tri(wp.vec3d(a)*scale,wp.vec3d(b)*scale,wp.vec3d(c)*scale,
                                wp.vec3d(u)*scale,wp.vec3d(v)*scale,wp.vec3d(w)*scale)

@wp.kernel
def check_wire(q:wp.array[wp.vec3],faces:wp.array2d[int],mesh:wp.uint64,pose:wp.array[wp.transform],
               step:wp.array[int],hits:wp.array[int]):
    i=wp.tid()
    inv=wp.transform_inverse(pose[0])
    a=wp.transform_point(inv,q[faces[i,0]])
    b=wp.transform_point(inv,q[faces[i,1]])
    c=wp.transform_point(inv,q[faces[i,2]])
    query=wp.mesh_query_aabb(mesh,wp.min(a,wp.min(b,c)),wp.max(a,wp.max(b,c)))
    j=int(0)
    while wp.mesh_query_aabb_next(query,j):
        u=wp.mesh_get_point(mesh,3*j)
        v=wp.mesh_get_point(mesh,3*j+1)
        w=wp.mesh_get_point(mesh,3*j+2)
        if intersects(a,b,c,u,v,w):
            wp.atomic_add(hits,step[0],1)

@wp.kernel
def cap_center(q:wp.array[wp.vec3],offset:wp.array[int],verts:wp.array[int],centers:wp.array[wp.vec3]):
    i=wp.tid()
    s=wp.vec3(0.)
    for j in range(offset[i],offset[i+1]):
        s=s+q[verts[j]]
    centers[i]=s/float(offset[i+1]-offset[i])

@wp.kernel
def hook_outside(q:wp.array[wp.vec3],faces:wp.array2d[int],edges:wp.array2d[int],centers:wp.array[wp.vec3],
                 hook:wp.uint64,pose:wp.array[wp.transform],step:wp.array[int],cap_hits:wp.array[int],
                 solid_angle:wp.array[float]):
    i=wp.tid()
    a=wp.vec3(0.); b=wp.vec3(0.); c=wp.vec3(0.)
    if i<faces.shape[0]:
        a=q[faces[i,0]]; b=q[faces[i,1]]; c=q[faces[i,2]]
    else:
        j=i-faces.shape[0]
        a=q[edges[j,0]];b=q[edges[j,1]];c=centers[edges[j,2]]
        inv=wp.transform_inverse(pose[0])
        u=wp.transform_point(inv,a);v=wp.transform_point(inv,b);w=wp.transform_point(inv,c)
        query=wp.mesh_query_aabb(hook,wp.min(u,wp.min(v,w)),wp.max(u,wp.max(v,w)))
        f=int(0)
        while wp.mesh_query_aabb_next(query,f):
            if intersects(u,v,w,wp.mesh_get_point(hook,3*f),wp.mesh_get_point(hook,3*f+1),wp.mesh_get_point(hook,3*f+2)):
                wp.atomic_add(cap_hits,step[0],1)
    ref=wp.transform_point(pose[0],wp.vec3(.027,0.,.102))
    a=a-ref;b=b-ref;c=c-ref
    al=wp.length(a);bl=wp.length(b);cl=wp.length(c)
    angle=wp.atan2(wp.dot(a,wp.cross(b,c)), al*bl*cl+cl*wp.dot(a,b)+al*wp.dot(b,c)+bl*wp.dot(c,a))
    wp.atomic_add(solid_angle,step[0],angle/(2.*wp.pi))

@wp.kernel
def increment(step:wp.array[int]):
    step[0]+=1

def fixture():
    joints=''; motors=''
    for i,(axis,typ) in enumerate(zip(['1 0 0','0 1 0','0 0 1','0 0 1','0 1 0'],['slide']*3+['hinge']*2)):
        joints+=f'<joint name="j{i}" type="{typ}" axis="{axis}"/>'
        motors+=f'<position joint="j{i}" kp="{800 if i<3 else 12}" kv="{14 if i<3 else .35}"/>'
    xml=f"""<mujoco><option timestep="{DT}" gravity="0 0 0"/><worldbody><body>{joints}
    <inertial pos="0 0 0" mass=".08" diaginertia=".001 .001 .001"/></body></worldbody>
    <actuator>{motors}</actuator></mujoco>"""
    m=mujoco.MjModel.from_xml_string(xml)
    return mjw.put_model(m),mjw.make_data(m,nworld=1)

def main():
    OUT.mkdir(exist_ok=True)
    with np.load(ASSETS/'Female_T_Shirt_panels.npz') as data:
        rest,faces=data['vertices'].copy(),data['faces']
        uv,corners=data['uv'],data['corners']
    # Register the opposite-facing neckline with the hanger approach; preserve all lengths.
    rest[:,:2]*=-1
    rest += [0.,.110,-.033]
    garment = rest.copy()
    # Start with the open hem at tabletop height; the shoulder grip is active from frame zero.
    rest=rest.copy()
    rest[:,1]-=.06
    rest[:,2]+=.42-rest[:,2].min()
    builder=newton.ModelBuilder(gravity=(0.,0.,-9.81))
    newton.solvers.SolverStyle3D.register_custom_attributes(builder)
    body=builder.add_body(is_kinematic=True)
    wire,wf=read_mesh(ASSETS/'wire.obj')
    wire_cfg=builder.default_shape_cfg.copy();wire_cfg.margin=.006
    builder.add_shape_mesh(body,mesh=newton.Mesh(wire-PIV,wf.ravel()),cfg=wire_cfg)
    pad_cfg=builder.default_shape_cfg.copy()
    pad_cfg.margin=.002
    for x,z,r in shoulder_pads():
        builder.add_shape_sphere(body,xform=wp.transform(np.array([x,DEPTH,z])-PIV,wp.quat_identity()),radius=r,cfg=pad_cfg)
    builder.add_shape_box(-1,xform=wp.transform((0.,.16,.38),wp.quat_identity()),hx=.70,hy=.63,hz=.04)
    assert corners.shape==faces.shape and len(faces)==89912
    style3d.add_cloth_mesh(builder,pos=(0,0,0),rot=wp.quat_identity(),vel=(0,0,0),vertices=rest,
        indices=faces.ravel().tolist(),density=.3,particle_radius=.005,panel_verts=uv,panel_indices=corners,
        tri_aniso_ke=wp.vec3(100.,100.,10.),edge_aniso_ke=wp.vec3(2e-5,1e-5,5e-6))
    model=builder.finalize(device='cuda:0')
    model.soft_contact_ke,model.soft_contact_kd,model.soft_contact_mu=500.,1e-5,.2
    state=[model.state(),model.state()];pipe=newton.CollisionPipeline(model)
    contacts=pipe.contacts();cmd=model.control();solver=newton.solvers.SolverStyle3D(model,iterations=4)
    rigid,rd=fixture()
    def patch(near,n):
        return np.argsort(np.linalg.norm(garment-np.asarray(near),axis=1))[:n]
    ids=[np.flatnonzero((garment[:,0]>.020)&(garment[:,0]<.133)&(garment[:,2]>1.067)),patch((-.147,.058,1.079),180)]

    # Keep high-resolution neighboring triangles free to respond to contact.
    # Match the physical footprint of the virtual jaw, rather than fixing every vertex in it.
    def spaced(pool,spacing):
        chosen=[]
        for idx in sorted(pool):
            if not chosen or np.min(np.linalg.norm(garment[chosen]-garment[idx],axis=1)) >= spacing:
                chosen.append(idx)
        return np.array(chosen)
    ids=[spaced(ids[0],.014),spaced(ids[1],.012)]
    print("anchors",len(ids[0]),len(ids[1]),flush=True)
    # True neck boundary.
    edges,cnt=np.unique(np.sort(faces[:,[[0,1],[1,2],[2,0]]].reshape(-1,2),axis=1),axis=0,return_counts=True)
    rim=np.unique(edges[cnt==1]);collar=rim[(garment[rim,2]>1.06)&(abs(garment[rim,0])<.08)]
    group=np.full(len(rest),-1,np.int32)
    for i,g in enumerate(ids):group[g]=i
    group=wp.array(group,dtype=int)
    active=wp.array([1,0],dtype=int)
    delta=wp.zeros(2,dtype=wp.vec3)
    saved=wp.array(rest,dtype=wp.vec3)
    initial=np.array([-.32,-.25,1.06,0.,.8],np.float32)
    target=wp.array(initial,dtype=float)
    rd.qpos.assign(initial[None]);wp.launch(transfer,1,[rd.qpos,state[0].body_q])
    wp.launch(transfer,1,[rd.qpos,state[1].body_q])
    pads=wp.array([(x,0.,z-PIV[2]) for x,z,_ in shoulder_pads()],dtype=wp.vec3)
    wm=wp.Mesh(points=wp.array(wire-PIV,dtype=wp.vec3),indices=wp.array(wf.ravel(),dtype=int))
    from verify import caps
    loops=caps(faces)
    cap_offsets=wp.array(np.cumsum([0]+[len(l) for l in loops]),dtype=int)
    cap_vertices=wp.array(np.concatenate(loops),dtype=int)
    cap_edges=wp.array(np.vstack([np.column_stack((l,np.roll(l,-1),np.full(len(l),k))) for k,l in enumerate(loops)]),dtype=int)
    center_buffer=wp.zeros(len(loops),dtype=wp.vec3)
    # All 16 curved tube spans and the tip cap (512+14 faces); exclude the straight neck stem.
    upper_faces=wf[wire[wf][:,:,2].min(axis=1)>PIV[2]+.05]
    assert len(upper_faces)==526
    hook_mesh=wp.Mesh(points=wp.array(wire-PIV,dtype=wp.vec3),indices=wp.array(upper_faces.ravel(),dtype=int))
    cap_hits=wp.zeros(12000,dtype=int)
    winding=wp.zeros(12000,dtype=float)
    hits=wp.zeros(12000,dtype=int)
    counter=wp.zeros(1,dtype=int);gap=wp.full(12000,.026,dtype=float)
    def substep(i):
        a,b=state[i],state[1-i]
        wp.launch(control,5,[target,rd.ctrl]);mjw.step(rigid,rd)
        wp.launch(transfer,1,[rd.qpos,b.body_q])
        a.clear_forces();wp.launch(grip,len(rest),[group,active,delta,saved,model.particle_flags,a.particle_q,a.particle_qd])
        pipe.collide(a,contacts);solver.step(a,b,cmd,contacts,DT)
        wp.launch(clearance,(len(faces),len(pads)),[b.particle_q,model.tri_indices,pads,b.body_q,counter,gap])
        wp.launch(check_wire,len(faces),[b.particle_q,model.tri_indices,wm.id,b.body_q,counter,hits])
        wp.launch(cap_center,len(loops),[b.particle_q,cap_offsets,cap_vertices,center_buffer])
        wp.launch(hook_outside,len(faces)+len(cap_edges),[b.particle_q,model.tri_indices,cap_edges,center_buffer,hook_mesh.id,b.body_q,counter,cap_hits,winding])
        wp.launch(increment,1,[counter])
    with wp.ScopedCapture() as cap:
        for k in range(20):substep(k%2)
    report_start=0
    positions=[rest];poses=[initial];holds=[[True,False]]
    hand=np.zeros((2,3),np.float32)
    def run(seconds,goal,displacement,flags):
        nonlocal report_start
        start=poses[-1].copy();old=hand.copy()
        active.assign(np.array(flags,np.int32))
        for k in range(round(seconds*FPS)):
            u=(k+1)/round(seconds*FPS);u=u*u*(3-2*u)
            target.assign(np.array(start+(goal-start)*u,np.float32))
            hand[:]=old+(displacement-old)*u;delta.assign(hand)
            wp.capture_launch(cap.graph)
            positions.append(state[0].particle_q.numpy());assert np.isfinite(positions[-1]).all();poses.append(rd.qpos.numpy()[0].copy());holds.append(flags)
        stop=int(counter.numpy()[0])
        seg=slice(report_start,stop)
        print("audit",stop/600, gap.numpy()[seg].min()*1000, np.count_nonzero(hits.numpy()[seg]),np.count_nonzero(cap_hits.numpy()[seg]),np.max(np.abs(winding.numpy()[seg])),flush=True)
        report_start=stop
        v=positions[-1]
        print(len(poses)/30,'neck',v[collar].mean(0),'neck bounds',v[collar].min(0),v[collar].max(0),'shoulders',v[ids[0]].mean(0),v[ids[1]].mean(0),'low',v[:,2].min(),flush=True)
    lift=np.array([[0.,0.,.16],[0.,0.,0.]])
    run(1.,initial,lift,[1,0])
    def from_tip(tip,yaw,pitch):
        # Keep the first shoulder pad at the specified world point while pivoting the hanger.
        x,z=.205,-.075
        horizontal=np.cos(pitch)*x+np.sin(pitch)*z
        offset=np.array([np.cos(yaw)*horizontal,np.sin(yaw)*horizontal,-np.sin(pitch)*x+np.cos(pitch)*z])
        return np.r_[np.asarray(tip)-offset,yaw,pitch]

    # The held shoulder includes both lips of the adjacent collar section.
    offset=rest[ids[0]].mean(0)-garment[ids[0]].mean(0)+lift[0]
    def pt(x,y,z):return np.array([x,y,z])+offset
    run(.8,from_tip(pt(-.055,.018,1.20),0.,.62),lift,[1,0])
    run(.75,from_tip(pt(.037,.033,1.056),0.,.62),lift,[1,0])
    run(.7,from_tip(pt(.135,.046,.934),0.,.62),lift,[1,0])
    now=positions[-1].copy()
    saved_np=rest.copy()
    saved_np[ids[1]]=now[ids[1]]
    saved.assign(saved_np)
    sleeve=now[ids[1]].mean(0)
    def hands(to):
        return np.array([lift[0],np.asarray(to)-sleeve])
    two=hands(pt(-.230,.037,1.104))
    run(1.1,from_tip(pt(.135,.046,.928),0.,.62),two,[1,1])
    # Once the other sleeve is held, leave only the outer pinch fixed so that
    # the neck edge can slide around the hanger rather than intersect a fixed patch.
    narrow=group.numpy()
    narrow[(narrow==0)&(garment[:,0]<.104)] = -1
    group.assign(narrow)
    two[0]=lift[0]+[.066,.006,.061]
    run(.70,from_tip(pt(.13,.040,.967),0.,.57),two,[1,1])
    def pivot(x,y,z,angle):
        return np.r_[pt(x,y,z),0.,angle]
    # Keep the hook above the collar. Carry the near end into the sleeve
    # while moving the far tip over the opening widened by the opposite hand.
    run(.9,pivot(.066,.035,1.147,.52),two,[1,1])
    run(.8,pivot(.085,.035,1.122,.30),two,[1,1])
    run(.75,pivot(.081,.035,1.116,.02),two,[1,1])
    balance=two.copy()
    run(.85,pivot(.005,.043,1.11,0.),balance,[1,1])
    final=pivot(0.,.055,1.100,0.)
    two=balance.copy()
    run(.6,final,two,[1,1])
    run(.8,final,two,[0,0])
    for offset_x in [.03,-.03,.03,-.03,0.]:
        goal=final.copy();goal[0]+=offset_x
        run(.35,goal,two,[0,0])
    run(.8,final,two,[0,0])
    np.savez_compressed(OUT/'trajectory.npz',pos=np.array(positions),pose=np.array(poses),active=np.array(holds),faces=faces,grip_ids_0=ids[0],grip_ids_1=ids[1],collar=collar,hook_cap_hits=cap_hits.numpy()[:int(counter.numpy()[0])],hook_winding=winding.numpy()[:int(counter.numpy()[0])],wire_hits=hits.numpy()[:int(counter.numpy()[0])],pad_gap=gap.numpy()[:int(counter.numpy()[0])])

if __name__=='__main__':main()
