"""Position an already-threaded sweatshirt on the same hanger, settle, shake and stop.

Place beside simulate.py in the standalone T-shirt example. Input: sweatshirt.npz
with vertices in Z-up metres (USD x, -z, y), faces, panel uv and corners.
"""
from pathlib import Path
import numpy as np
import newton
import warp as wp
import simulate as sim
from verify import caps, winding
from newton.solvers import style3d

def run():
    base = Path(__file__).resolve().parent
    data = np.load(base / "sweatshirt.npz")
    verts = data["vertices"] + np.array([0, .043, -.373], np.float32)
    faces = data["faces"]
    builder = newton.ModelBuilder(gravity=(0, 0, -9.81))
    newton.solvers.SolverStyle3D.register_custom_attributes(builder)
    hanger = builder.add_body(is_kinematic=True)
    wire, wf = sim.read_mesh(sim.ASSETS / "wire.obj")
    wire = wire - sim.PIV
    config = builder.default_shape_cfg.copy()
    config.margin = .006
    builder.add_shape_mesh(hanger, mesh=newton.Mesh(wire,wf.ravel()), cfg=config)
    config = builder.default_shape_cfg.copy()
    config.margin = .002
    centers = np.array([(x,0,z-sim.PIV[2]) for x,z,_ in sim.shoulder_pads()])
    for center in centers:
        builder.add_shape_sphere(hanger, xform=wp.transform(center,wp.quat_identity()), radius=.024, cfg=config)
    style3d.add_cloth_mesh(builder, pos=(0,0,0),rot=wp.quat_identity(),vel=(0,0,0),
        vertices=verts,indices=faces.ravel().tolist(),density=.3,particle_radius=.005,
        panel_verts=data["uv"],panel_indices=data["corners"],
        tri_aniso_ke=wp.vec3(100,100,10),edge_aniso_ke=wp.vec3(2e-5,1e-5,5e-6))
    model=builder.finalize(device="cuda:0")
    model.soft_contact_ke,model.soft_contact_kd,model.soft_contact_mu=500.,1e-5,.2
    solver=newton.solvers.SolverStyle3D(model,iterations=4)
    pipe=newton.CollisionPipeline(model)
    contacts,cmd=pipe.contacts(),model.control()
    st=[model.state(),model.state()]
    rigid,rd=sim.fixture()
    initial=np.r_[sim.PIV,0.,0.].astype(np.float32)
    target=wp.array(initial,dtype=float)
    rd.qpos.assign(initial[None])
    for s in st:
        wp.launch(sim.transfer,1,[rd.qpos,s.body_q])
    loops=caps(faces)
    assert len(loops)==4
    offsets=wp.array(np.cumsum([0]+list(map(len,loops))),dtype=int)
    indices=wp.array(np.concatenate(loops),dtype=int)
    edges=wp.array(np.vstack([np.column_stack((l,np.roll(l,-1),np.full(len(l),i))) for i,l in enumerate(loops)]),dtype=int)
    cap_pos=wp.zeros(4,dtype=wp.vec3)
    hk=wf[wire[wf][:,:,2].min(axis=1)>.05]
    assert len(hk)==526
    mesh=lambda f: wp.Mesh(points=wp.array(wire,dtype=wp.vec3),indices=wp.array(f.ravel(),dtype=int))
    wm,hm=mesh(wf),mesh(hk)
    pads=wp.array(centers,dtype=wp.vec3)
    n=3600
    gap=wp.full(n+1,.026,dtype=float)
    wire_hits=wp.zeros(n+1,dtype=int)
    hook_hits=wp.zeros(n+1,dtype=int)
    wind=wp.zeros(n+1,dtype=float)
    tick=wp.zeros(1,dtype=int)
    def audit(state):
        q,pose=state.particle_q,state.body_q
        wp.launch(sim.clearance,(len(faces),len(pads)),[q,model.tri_indices,pads,pose,tick,gap])
        wp.launch(sim.check_wire,len(faces),[q,model.tri_indices,wm.id,pose,tick,wire_hits])
        wp.launch(sim.cap_center,len(loops),[q,offsets,indices,cap_pos])
        wp.launch(sim.hook_outside,len(faces)+len(edges),[q,model.tri_indices,edges,cap_pos,hm.id,pose,tick,hook_hits,wind])
        wp.launch(sim.increment,1,[tick])
    audit(st[0])
    print("initial gap/wire/hook/winding",gap.numpy()[0],wire_hits.numpy()[0],hook_hits.numpy()[0],wind.numpy()[0],flush=True)
    with wp.ScopedCapture() as cap:
        for i in range(20):
            a,b=st[i%2],st[1-i%2]
            wp.launch(sim.control,5,[target,rd.ctrl])
            sim.mjw.step(rigid,rd)
            wp.launch(sim.transfer,1,[rd.qpos,b.body_q])
            a.clear_forces()
            pipe.collide(a,contacts)
            solver.step(a,b,cmd,contacts,sim.DT)
            audit(b)
    pos=[verts]
    poses=[initial]
    for k in range(1,181):
        u=np.clip(k/30-3,0,2)
        goal=initial.copy()
        goal[0]=.03*np.sin(2*np.pi*u)*np.sin(np.pi*u/2)**2
        target.assign(goal)
        wp.capture_launch(cap.graph)
        pos.append(st[0].particle_q.numpy())
        poses.append(rd.qpos.numpy()[0].copy())
    pos=np.array(pos)
    poses=np.array(poses)
    members=np.array([[winding(v,faces,loops,x)>.5 for x in centers[[0,8,9,17]]+q[:3]] for v,q in zip(pos,poses)])
    print("min gap mm",gap.numpy().min()*1000,"wire steps",np.count_nonzero(wire_hits.numpy()),
          "hook cap steps",np.count_nonzero(hook_hits.numpy()),"max |winding|",abs(wind.numpy()).max(),
          "four pads inside frames",members.all(1).sum(),"min z at end",pos[-1,:,2].min(),flush=True)
    assert np.isfinite(pos).all() and int(tick.numpy()[0])==n+1
    np.savez_compressed(base/"sweatshirt_trajectory.npz",pos=pos,pose=poses,faces=faces,
        gap=gap.numpy(),wire=wire_hits.numpy(),cap=hook_hits.numpy(),winding=wind.numpy(),inside=members)
    assert members.all() and gap.numpy().min()>0 and not wire_hits.numpy().any() and not hook_hits.numpy().any() and abs(wind.numpy()).max()<.01

if __name__=="__main__":
    run()
