from pathlib import Path
import subprocess
import numpy as np
import mujoco
from setup_scene import ASSETS, DEPTH
from render import ffmpeg as find_ffmpeg

def render(pos, faces, hanger_x=None):
    eye = np.array([.32,1.62,1.02])
    view = np.array([0.,DEPTH,.82])-eye
    right = np.cross(view, [0.,0.,1.])
    up = np.cross(right, view)
    def values(array):
        return " ".join(map(str, np.asarray(array).flatten()))
    xml = f"""<mujoco><visual><global offwidth="640" offheight="480"/></visual>
    <asset><material name="matte_cloth" rgba=".17 .48 .77 1" specular="0" shininess="0" reflectance="0"/><mesh name="hanger" file="{(ASSETS/'hanger.obj').as_posix()}"/></asset>
    <worldbody><body name="rack" mocap="true"><geom type="mesh" mesh="hanger" rgba=".88 .58 .22 1"/></body>
    <light pos="1 2 3" dir="-.3 -.6 -1"/>
    <camera name="front" pos="{values(eye)}" xyaxes="{values(right)} {values(up)}" fovy="35"/>
    </worldbody><deformable><flex name="shirt" dim="2" body="world" vertex="{values(pos[0])}"
    element="{values(faces)}" radius=".001" material="matte_cloth"/></deformable></mujoco>"""
    model = mujoco.MjModel.from_xml_string(xml)
    assert model.flex_matid[0]>=0 and model.mat_specular[model.flex_matid[0]]==0
    data = mujoco.MjData(model)
    mujoco.mj_forward(model, data)
    ffmpeg = find_ffmpeg()
    command = [str(ffmpeg), "-loglevel","error","-y","-f","rawvideo","-pix_fmt","rgb24",
               "-s","640x480","-r","30","-i","-","-c:v","libx264","-pix_fmt","yuv420p",str(Path(__file__).with_name("sweatshirt.mp4"))]
    with mujoco.Renderer(model, height=480, width=640) as renderer, subprocess.Popen(command, stdin=subprocess.PIPE) as enc:
        for frame, points in enumerate(pos):
            if hanger_x is not None:
                data.mocap_pos[0,0] = hanger_x[frame]
                mujoco.mj_forward(model, data)
            data.flexvert_xpos[:] = points
            renderer.update_scene(data, camera="front")
            enc.stdin.write(renderer.render().tobytes())
        enc.stdin.close()
        assert enc.wait() == 0


if __name__ == '__main__':
    d = np.load(Path(__file__).with_name('sweatshirt_trajectory.npz'))
    render(d['pos'], d['faces'], d['pose'][:, 0])
