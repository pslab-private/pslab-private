from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parent
ASSETS = ROOT / "assets"
OUT = ROOT / "output"
LIFT = .80
DEPTH = .063

def shoulder_pads():
    for sign in (-1, 1):
        for distance in np.linspace(.068, .205, 9):
            yield sign*distance, LIFT+.278-.38*distance, .024


def read_mesh(path):
    points, faces = [], []
    for line in path.read_text().splitlines():
        parts = line.split()
        if parts[:1] == ["v"]:
            points.append(list(map(float, parts[1:4])))
        elif parts[:1] == ["f"]:
            assert len(parts) == 4
            faces.append([int(index.split("/")[0])-1 for index in parts[1:]])
    return np.array(points, dtype=np.float32), np.array(faces, dtype=np.int32)


def local_panels(vertices, faces):
    # No UVs in the shirt. Project world-up into the tangent plane as a yarn-axis proxy.
    tri = vertices[faces].astype(float)
    e = tri[:,1:] - tri[:,:1]
    n = np.cross(e[:,0], e[:,1])
    area2 = np.linalg.norm(n,axis=1)
    n /= area2[:,None]
    u = np.cross([0.,0.,1.],n)
    u[np.linalg.norm(u,axis=1)<1e-8] = [1.,0.,0.]
    u /= np.linalg.norm(u,axis=1)[:,None]
    v = np.cross(n,u)
    uv = np.zeros((len(tri),3,2))
    uv[:,1:,0] = np.einsum("fij,fj->fi",e,u)
    uv[:,1:,1] = np.einsum("fij,fj->fi",e,v)
    assert np.allclose(np.linalg.det(uv[:,1:]),area2)
    return uv.reshape(-1,2),np.arange(faces.size)
